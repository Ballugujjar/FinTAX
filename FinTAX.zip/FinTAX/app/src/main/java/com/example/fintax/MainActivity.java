package com.example.fintax;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {
    TextView textView5,textView4;
    EditText editTextNumberDecimal1,editTextNumber1;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView5 = findViewById(R.id.textView5);
        textView4 = findViewById(R.id.textView4);
        editTextNumberDecimal1 = findViewById(R.id.editTextNumberDecimal1);
        editTextNumber1 = findViewById(R.id.editTextNumber1);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num = Integer.parseInt(editTextNumber1.getText().toString());
                float percentage = Float.parseFloat(editTextNumberDecimal1.getText().toString());
                float net_gst = num*percentage/100;
                textView4.setText("Net GST is = "+ net_gst);
                float total = num+net_gst;
                textView5.setText("Net payable amount would be = "+ total);
            }
        });
    }
}